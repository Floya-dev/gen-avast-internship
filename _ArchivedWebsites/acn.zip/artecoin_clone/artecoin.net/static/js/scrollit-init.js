$(function () {
    $.scrollIt();
});